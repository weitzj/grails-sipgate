def configFile = new File("${basedir}/grails-app", 'conf/Config.groovy')
	if (configFile.exists()) {
		configFile.withWriterAppend {
			it.writeLine '\n// Added by the Sipgate plugin:'
			it.writeLine "grails.plugins.sipgate.username = 'YOUR_USERNAME'"
            it.writeLine "grails.plugins.sipgate.password = 'YOUR_PASSWORD'"
		}

        println '''
*******************************************************
* You've installed the Sipgate plugin.                *
*                                                     *
* Next edit your "conf/Config.groovy" and add your    *
* Sipgate credentials                                 *
*                                                     *
*******************************************************
'''
	}
else {
        println '''
*******************************************************
* Could not find your "conf/Config.groovy" file       *
*                                                     *
* The plugin will not work unless "conf/Config.groovy *
* is present. Make sure the config file is present at *
* the location specified and re-run the plugin        *
* installation process.                               *
*                                                     *
*******************************************************
'''
    }


